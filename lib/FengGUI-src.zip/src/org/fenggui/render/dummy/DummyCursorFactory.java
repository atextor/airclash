package org.fenggui.render.dummy;

import java.awt.image.BufferedImage;

import org.fenggui.render.Cursor;
import org.fenggui.render.CursorFactory;

public class DummyCursorFactory extends CursorFactory
{

	@Override
	public Cursor createCursor(int xHotspot, int yHotspot, BufferedImage image) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getDefaultCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getHandCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getMoveCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getTextCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getHorizontalResizeCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getVerticalResizeCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getNWResizeCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cursor getSWResizeCursor() {
		// TODO Auto-generated method stub
		return null;
	}

}
