package org.fenggui.render.dummy;

import org.fenggui.render.Cursor;

public class DummyCursor extends Cursor
{

	@Override
	public void show() 
	{
		
	}

}
