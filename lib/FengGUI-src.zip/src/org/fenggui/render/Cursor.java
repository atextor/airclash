package org.fenggui.render;

/**
 * Represents mouse cursor in FengGUI.
 * 
 * @author Johannes, last edited by $Author: schabby $, $Date: 2006-10-05 03:37:07 +0200 (Thu, 05 Oct 2006) $
 * @version $Revision: 28 $
 */
public abstract class Cursor 
{

	public abstract void show();
	
}
